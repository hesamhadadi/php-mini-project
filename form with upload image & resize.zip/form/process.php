<?php
include_once('functions.php');
uploader_files($_POST['name'],"pictures/","image");
echo "Success"
?>